import React from "react";
import { createBrowserRouter } from "react-router";
import Root from "../pages/Root/Root";
import ErrorPage from "../pages/ErrorPage/ErrorPage";
import Home from "../pages/Home/Home";
import Stores from "../pages/Stores/Stores";
import Installation from "../pages/Installation/Installation";
import AppDetails from "../pages/AppDetails/AppDetails";

export const router = createBrowserRouter([
  {
    path: "/",
    Component:Root,
    errorElement:<ErrorPage></ErrorPage> ,
   
    children: [
        {
            index: true,
            loader:()=>fetch('/AppsData.json'),
            path:"/",
            Component:Home
        },
        {
          path:'/store',
          Component:Stores,
          loader:()=>fetch('/AllAppsData.json')
          
        },
        {
          path:'/installation',
          Component:Installation,
          loader:()=>fetch('/AllAppsData.json')
        },
        {
          path:'/appDetails/[object Object]',
          Component:AppDetails,
          loader:()=>fetch('/AllAppsData.json')
        }
      ]
    },
      ]);

