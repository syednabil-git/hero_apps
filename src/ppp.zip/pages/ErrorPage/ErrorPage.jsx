import React from "react";
 const ErrorPage = () => {
    return (
        <div>
            <h1> hellow error</h1>
        </div>
    );
 };
 export default ErrorPage;