import React from "react";
import { useLoaderData } from "react-router";
import downloads from "../../assets/downloads.png"
import rating from "../../assets/ratings.png"
const Installation = () =>{
    const installation = useLoaderData();
    return(
        <div className="mb-20">
           <div className="">
                <div className="text-center">
             <h1 className="font-bold text-4xl mb-2 mt-15">Your Installed Apps</h1>
            <p>Explore All Trending Apps on the Market developed by us</p>
           </div>
           <div className="flex justify-between items-center">
                <p className="font-bold"><span>1</span> Apps Found</p>
                <div className="dropdown">
                    <div tabIndex={0} role="button" className="btn m-1 w-[200px] font-bold">Sort By Size</div>
                    <ul tabIndex="-1" className="dropdown-content menu bg-base-100 rounded-box z-1 w-52 p-2 shadow-sm font-bold">
                            <li><a>Sort by size</a></li>
                            <li><a>Sort by rating</a></li>
                    </ul>
                    </div>
           </div>

           {/* App list */}

           {
            installation.map(items => (
                <div className="flex justify-between items-center p-2 bg-white shadow-2xl mt-2">
                <div className="flex items-center">
                <div className="mr-5">
                    <img className=" w-20 h-20 rounded-4xl" src={items.image}></img>
                </div>
                <div>
                    <h1 className="font-bold text-xl">Forest: Focus for Productivity</h1>
                    <div className="flex items-center">
                        <p className="text-green-500 font-bold flex items-center"><span className="mr-1"><img className="h-4" src={downloads}></img></span>9M</p>
                        <p className="ml-4 text-red-500 font-bold flex items-center"><span className="mr-1"><img className="h-4" src={rating}></img></span>5</p>
                        <p className="ml-4 text-gray-500">258 MB</p>
                    </div>
                </div>
           </div>
           
            <div>
                <button className="btn bg-green-700 text-white text-xl rounded-lg">Uninstall</button>
           </div>
           </div>
            ))
           }
           
           </div>
        </div>
    );
};
export default Installation;