import React from "react";
import download from "../../assets/downloads.png"
import rating from "../../assets/ratings.png"
import review from "../../assets/review.png"
import { useLoaderData, useParams } from "react-router";
const AppDetails = () =>{
    const { id } = useParams();
    const appId = parseInt("[object Object]");
    const data = useLoaderData();
    const singleApp = data.find(app => app.id === NaN);
    const { image,title,companyName,downloads,ratingAvg,reviews,description,size } = singleApp;
    return(
        <div>
            <div className="flex border-b-2 border-gray-300 mt-20">
            <div className="img mr-10">
                <img className="w-[350px] h-[270px] rounded-4xl" src={image}></img>
            </div>
            <div className=" w-full">
                <div className="border-b-2 border-gray-300">
                    <h1 className="text-3xl font-bold">
                       {title} 
                    </h1>
                    <p className="text-xl mb-5 mt-2">Developed by <span className="text-blue-700 ml-1 font-bold">{companyName}</span></p>
                </div>
                <div className="flex items-center mt-5">
                    <div className="">
                        <img className="w-7" src={download}></img>
                        <p>downloads</p>
                        <p className="font-bold text-3xl">{downloads}</p>
                    </div>
                    <div className="ml-20">
                        <img className="w-7" src={rating}></img>
                        <p>Average Ratings</p>
                        <p className="font-bold text-3xl">{ratingAvg}</p>
                    </div>
                    <div className="ml-20">
                        <img className="w-9" src={review}></img>
                        <p>Total Reviews</p>
                        <p className="font-bold text-3xl">{reviews}</p>
                    </div>
                </div>
                <div>
                    <button className="btn bg-green-500 text-white text-lg mb-5 mt-5 shadow-lg">
                        Install Now (<span>{size}</span> MB)
                    </button>
                </div>
            </div>
            </div>
            {/* Ratings */}
            <div className="w-full h-[350px] mt-10 border-b-2 border-gray-300">
                <p className="text-xl font-bold">Ratings</p>
            </div>
            {/* Description */}
            <div className="mt-10 mb-15">
                <h1 className="text-xl font-bold">Description</h1>
                <p>{description}</p>
            </div>
        </div>
    );
};
export default AppDetails;