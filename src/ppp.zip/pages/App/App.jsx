import React from "react";
import logo from "../../assets/downloads.png";
import Rating from "../../assets/ratings.png";
import { Link } from "react-router";
const App = ({singleApp}) =>{
    const {image,title,ratingAvg,downloads,id} = singleApp;
    return(
        <Link to={`/appDetails/${id}`}>
                <div>
            <div className="w-[280px] h-[280px] rounded-xl shadow-2xl p-2">
                <div className="items-center flex justify-center">
                    <img className="h-[200px] w-full rounded-xl" src={image}></img>
                </div>
                <div>
                    <p className="text-[20px] font-semibold">{title}</p>
                </div>
                <div className="flex justify-between items-center">
                    <div className="flex justify-center items-center">
                       <img className="w-[18px] h-[20px] mr-1" src={logo}></img>
                        <p className="text-xl font-semibold">{downloads}</p>
                    </div>
                    <div className="flex justify-center items-center">
                       <img className="w-[18px] h-[20px] mr-1" src={Rating}></img>
                        <p className="text-xl font-semibold">{ratingAvg}</p>
                    </div>
                    
                </div>
            </div>
        </div>
        </Link>
    );
};
export default App;