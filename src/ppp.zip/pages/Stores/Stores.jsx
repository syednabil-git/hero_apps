import React from "react";
import { Link, useLoaderData } from "react-router";
import logo from "../../assets/downloads.png";
import Rating from "../../assets/ratings.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";


const Stores = () => {
  const stores = useLoaderData();

  return (
    <Link  to={`/appDetails/${id}`}>
          <div>
      <div className="text-center mt-20">
        <h1 className="text-4xl font-bold mb-5">Our All Applications</h1>
        <p className="text-xl">
          Explore All Apps on the Market developed by us. We code for Millions
        </p>
      </div>

      <div className="flex justify-between items-center mt-10">
        <p className="font-semibold text-xl">(132) Apps Found</p>
        <button className="btn w-[300px]"><FontAwesomeIcon icon={faMagnifyingGlass} className="mr-2" /> Search App</button>
      </div>

      <div className="grid grid-cols-4 gap-3 mt-10">
        {
             stores.map(store => (
                <div key={store.id} className="w-[280px] h-[280px] rounded-xl shadow-2xl p-2 ">
                                <div className="items-center flex justify-center">
                                    <img className="h-[200px] w-full rounded-2xl" src={store.image}></img>
                                </div>
                                <div>
                                    <p className="text-[20px] font-semibold">{store.title}</p>
                                </div>
                                <div className="flex justify-between items-center">
                                    <div className="flex justify-center items-center">
                                       <img className="w-[18px] h-[20px] mr-1" src={logo}></img>
                                        <p className="text-xl font-semibold">{store.downloads}</p>
                                    </div>
                                    <div className="flex justify-center items-center">
                                       <img className="w-[18px] h-[20px] mr-1" src={Rating}></img>
                                        <p className="text-xl font-semibold">{store.ratingAvg}</p>
                                    </div>
                                    
                                </div>
                            </div>
                
        ))
        }
      </div>
    </div>
    </Link>
  );
};

export default Stores;
